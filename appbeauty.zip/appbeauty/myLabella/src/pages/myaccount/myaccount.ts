import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-myaccount',
  templateUrl: 'myaccount.html'
})
export class MyAccountPage {

  constructor(public navCtrl: NavController) {

  }

}
