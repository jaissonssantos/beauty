import { Component, OnInit } from '@angular/core';
import { NavController, LoadingController, ToastController, App } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';

import { LoginPage } from '../../pages/login/login';

@Component({
  selector: 'page-myaccount',
  templateUrl: 'myaccount.html'
})
export class MyAccountPage implements OnInit {

  private error: any;
  private loading: any;
  private toast: any;
  private account = {};

  constructor(public navCtrl: NavController, public webService: RestProvider, public loadingCtrl: LoadingController, public toastCtrl: ToastController, public app: App) {
    this.loading = this.loadingCtrl.create({});
  }

  ngOnInit(){
    this.get();
  }
  
  get(){
    if(localStorage.getItem('users') != undefined){
      let data = JSON.parse(localStorage.getItem('users'));
      //set params
      this.account['id'] = data.id;
      this.account['name'] = data.nome;
      this.account['gender'] = data.sexo;
      this.account['email'] = data.email;
      this.account['phone'] = data.telefone;
      this.account['date'] = data.datanascimento;
    }
  }

  login(){
    this.app.getRootNav().setRoot(LoginPage);
  }

  logout(){
    this.account = {};
    localStorage.clear();
  }

}
