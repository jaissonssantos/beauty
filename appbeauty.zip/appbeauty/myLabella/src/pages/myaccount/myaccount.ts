import { Component, OnInit } from '@angular/core';
import { NavController, LoadingController, ToastController, App } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';

import { LoginPage } from '../../pages/login/login';

@Component({
  selector: 'page-myaccount',
  templateUrl: 'myaccount.html'
})
export class MyAccountPage implements OnInit {

  private error: any;
  private loading: any;
  private toast: any;
  private account = {};

  constructor(public navCtrl: NavController, public webService: RestProvider, public loadingCtrl: LoadingController, public toastCtrl: ToastController, public app: App) {
    this.loading = this.loadingCtrl.create({});
  }

  ngOnInit(){
    this.get();
  }
  
  get(){
    if(localStorage.getItem('users') != undefined){
      let data = JSON.parse(localStorage.getItem('users'));
      //set params
      this.account['id'] = data.id;
      this.account['name'] = data.nome;
      this.account['gender'] = data.sexo;
      this.account['email'] = data.email;
      this.account['phone'] = data.phone;
      this.account['date'] = data.datanascimento;
    }
  }

  save(){
    this.loading = this.loadingCtrl.create({  content: 'Salvando...' });
    this.loading.present();
    //update
    this.webService.postData('controller/mobile/cliente/update', this.account)
    .subscribe(
        data => {
          this.loading.dismiss();
          this.toast = this.toastCtrl.create({
            message: data.success,
            duration: 2000,
            position: 'bottom'
          });
          this.toast.onDidDismiss(this.dismissHandler);
          this.toast.present();
        },
        error => {
          console.log(error);
          this.loading.dismiss();
        }
    );   
  }

  login(){
    this.app.getRootNav().setRoot(LoginPage);
  }

  logout(){
    this.account = {};
    localStorage.clear();
  }

  private dismissHandler() {
    console.info('Toast onDidDismiss()');
  }

}
