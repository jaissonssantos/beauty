import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';


/**
 * Generated class for the SignupPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {

  private error: any;
  private users = {};

  constructor(public navCtrl: NavController, public navParams: NavParams, public webService: RestProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignupPage');
  }

  signup(){
    this.webService.postData('controller/mobile/cliente/create', this.users)
    .subscribe(
      data => {
        console.log(data.results);
        localStorage.setItem('users', JSON.stringify(data.results));
        console.log(localStorage.getItem('users'));
      },
      error => {
        let e = JSON.parse(error._body);
        this.error = e.error;
        console.log(e.error);
      }
    );
  }

}
