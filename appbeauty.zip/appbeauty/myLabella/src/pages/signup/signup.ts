import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';

import { TabsPage } from '../../pages/tabs/tabs';


/**
 * Generated class for the SignupPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {

  private error: any;
  private toast: any;
  private users = {};

  constructor(public navCtrl: NavController, public navParams: NavParams, public webService: RestProvider, public toastCtrl: ToastController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignupPage');
  }

  signup(){
    this.webService.postData('controller/mobile/cliente/create', this.users)
    .subscribe(
      data => {
        localStorage.setItem('users', JSON.stringify(data.results));
        console.log(localStorage.getItem('users'));
        this.toast = this.toastCtrl.create({
          message: data.success,
          duration: 2000,
          position: 'bottom'
        });
        this.toast.onDidDismiss(this.dismissHandler);
        this.toast.present();
        //set Homepage
        this.navCtrl.push(TabsPage);
      },
      error => {
        let e = JSON.parse(error._body);
        this.error = e.error;
        console.log(e.error);
      }
    );
  }

  private dismissHandler() {
    console.info('Toast onDidDismiss()');
  }

}
