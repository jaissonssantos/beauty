import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';

import { SignupPage } from '../../pages/signup/signup';
import { TabsPage } from '../../pages/tabs/tabs';

/**
 * Generated class for the LoginPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  private error: any;
  private loading: any;
  private users = {};

  constructor(public navCtrl: NavController, public navParams: NavParams, public webService: RestProvider, public loadingCtrl: LoadingController) {
    this.loading = this.loadingCtrl.create({  content: 'Autenticando...' });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  login(){
    this.loading.present();
    this.webService.postData('controller/mobile/cliente/login', this.users)
    .subscribe(
      data => {
        localStorage.setItem('users', JSON.stringify(data.results));
        this.loading.dismiss();
        console.log(localStorage.getItem('users'));
        //set Homepage
        this.navCtrl.push(TabsPage);
      },
      error => {
        let e = JSON.parse(error._body);
        this.error = e.error;
        this.loading.dismiss();
        console.log(e.error);
      }
    );
  }

  signup(){
    this.navCtrl.push(SignupPage);
  }

}
