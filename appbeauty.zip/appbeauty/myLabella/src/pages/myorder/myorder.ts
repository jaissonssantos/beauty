import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-myorder',
  templateUrl: 'myorder.html'
})
export class MyOrderPage {

  constructor(public navCtrl: NavController) {

  }

}
