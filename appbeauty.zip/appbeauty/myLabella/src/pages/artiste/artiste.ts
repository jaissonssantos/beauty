import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, App } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';

import { LoginPage } from '../../pages/login/login';

/**
 * Generated class for the ArtistePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-artiste',
  templateUrl: 'artiste.html',
})
export class ArtistePage {

  private params: any[];
  private artiste: any[];
  private loading: any;
  private toast: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public webService: RestProvider, public loadingCtrl: LoadingController, public toastCtrl: ToastController, public app: App) {
    this.loading = this.loadingCtrl.create({});
    //set params
    this.params = this.navParams.data;
  }

  ionViewDidLoad() {
    this.list();
  }

  list(){
    this.loading.present();
    //results
    this.webService.postData('controller/mobile/artista/list', this.params)
    .subscribe(
        data => {
          this.artiste = data.results;
          this.loading.dismiss();
        },
        error => {
          console.log(error);
          this.loading.dismiss();
        }
    );   
  }

  item(params){
    // console.log(params);
  }

  favorite(params){
    let users = {
      id: 1,
      nome: 'Mark Doe',
      sexo: 'M',
      email: 'markdoe@gmail.com',
      senha: 'f5c6ecd54de5927a5b53deb4948ad84d7a3e1ad3',
      telefone: '68999781476'
    }
    // localStorage.setItem('users', JSON.stringify(users));

    if(localStorage.getItem('users') == undefined){
      this.app.getRootNav().setRoot(LoginPage);
      return true;
    }else{
      let data = JSON.parse(localStorage.getItem('users'));
      params.idcliente = data.id;
    }
    //favorite
    this.webService.postData('controller/mobile/artista/favorite', params)
    .subscribe(
      data => {
        if(data.favorite){
          params.favorito = true;
        }else{
          params.favorito = false;
        }
        this.toast = this.toastCtrl.create({
          message: data.success,
          duration: 2000,
          position: 'bottom'
        });
        this.toast.onDidDismiss(this.dismissHandler);
        this.toast.present();
      },
      error => {
        console.log(error);
      }
    );
  }

  private dismissHandler() {
    console.info('Toast onDidDismiss()');
  }

}
