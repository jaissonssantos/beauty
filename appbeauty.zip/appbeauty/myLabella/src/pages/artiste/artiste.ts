import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';

/**
 * Generated class for the ArtistePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-artiste',
  templateUrl: 'artiste.html',
})
export class ArtistePage {

  private params: any[];
  private artiste: any[];
  private loading: any;
  private toast: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public webService: RestProvider, public loadingCtrl: LoadingController, public toastCtrl: ToastController) {
    this.loading = this.loadingCtrl.create({});
    //set params
    this.params = this.navParams.data;
  }

  ionViewDidLoad() {
    this.list();
  }

  list(){
    this.loading.present();
    //results
    this.webService.postData('controller/mobile/artista/list', this.params)
    .subscribe(
        data => {
          this.artiste = data.results;
          this.loading.dismiss();
        },
        error => {
          console.log(error);
          this.loading.dismiss();
        }
    );   
  }

  item(params){
    console.log(params);
  }

  favorite(params){
    params.idcliente = 1;
    //favorite
    this.webService.postData('controller/mobile/artista/favorite', params)
    .subscribe(
      data => {
        this.toast = this.toastCtrl.create({
          message: data.success,
          duration: 2000,
          position: 'bottom'
        });
        this.toast.onDidDismiss(this.dismissHandler);
        this.toast.present();
      },
      error => {
        console.log(error);
      }
    );
  }

  private dismissHandler() {
    console.info('Toast onDidDismiss()');
  }

}
