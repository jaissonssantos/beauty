import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';

/**
 * Generated class for the ServicePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-service',
  templateUrl: 'service.html',
})
export class ServicePage {

  private params: any[];
  private services: any[];
  private loading: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public webService: RestProvider, public loadingCtrl: LoadingController) {
    this.loading = this.loadingCtrl.create({
      content: 'Aguarde...'
    });
    //set params
    this.params = this.navParams.data;
  }

  ionViewDidLoad() {
    this.list();
  }

  list(){
    this.loading.present();
    //results
    this.webService.postData('controller/mobile/servico/list', this.params)
      .subscribe(
        data => {
          this.services = data.results;
          this.loading.dismiss();
        },
        error => {
          console.log(error);
          this.loading.dismiss();
        }
    );      
  }

}
