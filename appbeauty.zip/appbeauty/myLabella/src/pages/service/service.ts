import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, App } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';

import { ArtistePage } from '../../pages/artiste/artiste';

/**
 * Generated class for the ServicePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-service',
  templateUrl: 'service.html',
})
export class ServicePage {

  private params: any[];
  private services: any[];
  private loading: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public webService: RestProvider, public loadingCtrl: LoadingController, public app: App) {
    this.loading = this.loadingCtrl.create({});
    //set params
    this.params = this.navParams.data;
  }

  ionViewDidLoad() {
    this.list();
  }

  list(){
    this.loading.present();
    //results
    this.webService.postData('controller/mobile/servico/list', this.params)
      .subscribe(
        data => {
          this.services = data.results;
          this.loading.dismiss();
        },
        error => {
          console.log(error);
          this.loading.dismiss();
        }
    );      
  }

  item(params){
    console.log(params);
    this.navCtrl.push(ArtistePage, params);
    // this.app.getRootNav().setRoot(ArtistePage);
  }

}
