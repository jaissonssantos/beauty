import { Component, OnInit } from '@angular/core';
import { NavController, LoadingController } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';

import { ServicePage } from '../service/service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements OnInit {

  private categories: any[];
  private loading: any;

  constructor(public navCtrl: NavController, public webService: RestProvider, public loadingCtrl: LoadingController) {
    this.loading = this.loadingCtrl.create({});
  }

  ngOnInit(){
    this.list();
  }

  list(){
    this.loading.present();
    //results
    this.webService.getData('controller/mobile/categoria/list')
      .subscribe(
        data => {
          this.categories = data.results;
          this.loading.dismiss();
        },
        error => {
          console.log(error);
        }
    );      
  }

  item(params){
    this.navCtrl.push(ServicePage, params);
  }

}
