import { Injectable } from '@angular/core';
import { Http, Headers, Response, ResponseOptions } from '@angular/http';
import 'rxjs/add/operator/map';

import { Observable } from 'rxjs/Observable';

@Injectable()
export class RestProvider {

  private apiURL: String = "http://localhost/";

  constructor(public http: Http) {

  }
    
  getData(request){
    return this.http.get(this.apiURL + request).map(res => res.json());
  }

  postData(request, params){
    let headers = new Headers({ 'Content-Type' : 'application/x-www-form-urlencoded' });
    return this.http.post(this.apiURL + request,
      params,
      {
        headers: headers,
        method: 'POST'
      }).map(
      (res: Response) => {return res.json()}
    );
  }

}
